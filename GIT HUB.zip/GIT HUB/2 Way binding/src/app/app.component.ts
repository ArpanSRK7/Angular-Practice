import { Component } from "@angular/core";    
@Component({    
  selector: "app-root",    
  templateUrl: "./app.component.html",    
  styleUrls: ["./app.component.css"]    
})    
export class AppComponent {    
  firstName: string = "Arpan"; 
  lastName: string = "Sarkar";  
  age: number = 21;
  address: string = "137,Kolkata";
  state: string = "West Bengal";
}    