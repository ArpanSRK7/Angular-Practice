import { EmpIdPipe } from './emp-id.pipe';

describe('EmpIdPipe', () => {
  it('create an instance', () => {
    const pipe = new EmpIdPipe();
    expect(pipe).toBeTruthy();
  });
});
