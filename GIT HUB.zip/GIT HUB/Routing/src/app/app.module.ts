 
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';import { EmployeeService } from './Employees/employee.service';
import { ListEmployeessComponent } from './Employees/list-employees/list-employeess.component';
import { DashBoardEmployeeComponent } from './Employees/dash-board-employee/dash-board-employee.component';
import { CreateEmployeesComponent } from './Employees/create-employees/create-employees.component';

import { EmpIdPipe } from './Employees/emp-id.pipe';

const appRoutes: Routes = [
  { path: 'list', component: ListEmployeessComponent },
  { path: 'create', component: CreateEmployeesComponent },
  { path: 'home', component: DashBoardEmployeeComponent },
  { path: '', redirectTo: '/home', pathMatch: 'full' }
]

@NgModule({
  declarations: [
    AppComponent,
    ListEmployeessComponent,
    DashBoardEmployeeComponent,
    CreateEmployeesComponent,
    EmpIdPipe,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    RouterModule.forRoot(appRoutes),

  ],
  providers: [EmployeeService],
  bootstrap: [AppComponent]
})
export class AppModule { }
